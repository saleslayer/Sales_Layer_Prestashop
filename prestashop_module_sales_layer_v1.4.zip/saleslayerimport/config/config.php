<?php


define('COMPANY_NAME'   , 'Sales Layer');
define('COMPANY_TYPE'   , 'slyr');
define('DEBBUG_TYPE'    ,'print_r');
define('DEBBUG_PATH_LOG', dirname(__FILE__) .'/../logs/');
/*
error_reporting( E_ALL );
ini_set('display_errors', 1);
*/

?>